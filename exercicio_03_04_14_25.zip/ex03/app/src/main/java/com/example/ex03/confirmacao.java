package com.example.ex03;

import android.app.Activity;

public class confirmacao extends Activity {
}
